var props = {
  "color": "green",
  "taste" : "good"
};
